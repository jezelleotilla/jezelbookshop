-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2019 at 07:25 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jezelbookshop_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `title` varchar(30) NOT NULL,
  `short_description` text NOT NULL,
  `publication_date` date NOT NULL,
  `price` int(11) NOT NULL,
  `pdf_file` varchar(100) NOT NULL,
  `cover_photo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `isbn`, `title`, `short_description`, `publication_date`, `price`, `pdf_file`, `cover_photo`) VALUES
(30, '1', 'Html', 'Html Description', '2019-12-31', 50, '1576037906_df56a29b9d25bfdd72e1.pdf', '1576036483_a9be4c02636025502926.jpg'),
(31, '2', 'Css', 'This is css', '2019-12-19', 50, '1575863198_1e0d8dcd1fb3bfa4b89f.pdf', '1575863198_53438032ba32fd4b89dc.jpg'),
(32, '3', 'Javascript', 'This is javascript', '2019-12-18', 50, '1575863243_a55730f380c77ea36d2b.pdf', '1575863243_58088813f5625a31240f.jpg'),
(33, '4', 'PHP', 'this is php', '2019-12-27', 50, '1575863272_d4c8751d93ce8e54a977.pdf', '1575863272_735adbb5cd9dcea7641d.png'),
(34, '5', 'Java', 'This is java', '2019-12-23', 90, '1575863319_9428e2d0e8cc3b753167.pdf', '1575863319_110357001c288f6e936c.jpeg'),
(35, '6', 'Mysql', 'this is mysql', '2019-12-18', 60, '1575863567_946a701fbcbb01a8a2bd.pdf', '1575863567_1b0907062c37f6526487.png'),
(36, '7', 'C Language', 'This is C language', '2019-12-21', 80, '1575863639_52920f7e683f4da37a7b.pdf', '1575863639_57c0c8d198d23286f368.jpg'),
(37, '8', 'C Sharp', 'This is c sharp', '2019-12-25', 50, '1575863685_1c0695731dff63283bc8.pdf', '1575863685_d1f31fcfb9e13118448a.png'),
(38, '9', 'Matlab', 'This is matlab', '2019-12-18', 60, '1575863725_41fc7a41092e28340e3d.pdf', '1575863725_873ad715c806c1af5eff.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `book_id` int(11) NOT NULL,
  `cart_status` varchar(25) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `book_id`, `cart_status`) VALUES
(22, 7, 30, 'completed'),
(23, 7, 31, 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT 0,
  `carts` varchar(50) DEFAULT NULL,
  `image_proof` varchar(255) DEFAULT NULL,
  `order_status` varchar(50) NOT NULL DEFAULT 'pending',
  `payment_status` varchar(50) NOT NULL DEFAULT 'unpaid',
  `total_amount` int(11) NOT NULL DEFAULT 0,
  `order_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `carts`, `image_proof`, `order_status`, `payment_status`, `total_amount`, `order_date`) VALUES
(30, 7, '22,23', '1576044126_390dcbfb10035056c4e6.png', 'confirmed', 'paid', 100, '2019-12-11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(50) NOT NULL DEFAULT 'customer',
  `contact_number` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `create_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `password`, `user_type`, `contact_number`, `email`, `create_at`) VALUES
(5, 'Admin', 'Account', 'admin', '$2y$10$99R0WaKqixbXohvyF7k.qedi9hg3tCphyzp7SSzspaB/uZKQj/HEy', 'admin', '', '', '2019-12-11'),
(7, 'Jezel', 'Leotilla', 'jezel05', '$2y$10$D.gaDxw1rigOkk13w/E7l.Os2O7VPolfbYpYopXpvCU1G2XhKQoYu', 'customer', '', '', '2019-12-11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
